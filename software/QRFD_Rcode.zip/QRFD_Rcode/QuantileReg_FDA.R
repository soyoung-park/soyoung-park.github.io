QuantileReg_FDA <- function(data,ti,id.test,tau,pve=0.99){
  
  ############################################################
  #     Quantile Regression for Functional Data
  #   
  #     Input                          
  #     data: cbind(Y, U, x.mat)
  #           Y: response vector (n-by-1)
  #           U: scalar covariate vector (n-by-1)
  #           x.mat: functional covariate matrix (n-by-m)
  #     ti: sampling points (1-by-m)
  #     id.test: row id for testing set in data
  #     tau: quantile levels of interests  
  #     pve: percentage of variability explained, default=0.99
  # 
  #     Output                          
  #     predF.mono: predicted conditional distribution function 
  #     predQ: predicted conditional quantile 
  #     fixed.y: grid of y
  #     fit.pffr: fitted model of penalized function-on-function regression
  #               (see pffr in refund package)
  #
  #
  #     Author: Cai Li (cli9@ncsu.edu) 
  #     Created: 03/20/2016
  #         
  ############################################################
  library(refund)
  library(splines)
  options(warn=-1)
  
  ######################################
  # Read in data
  ######################################
  Y <- data[,1]                # Response
  U <- data[,2]                # Scalar covariate
  X <- data[,c(-1,-2)]         # Functional covariate
  n <- length(Y)
  Y.test <- Y[id.test]; Y.training <- Y[!(seq_len(n) %in% id.test)]
  U.test <- U[id.test]; U.training <- U[!(seq_len(n) %in% id.test)] 
  X.test <- X[id.test,]; X.training <- X[!(seq_len(n) %in% id.test),]
  
  ######################################
  # Pre-smoothing functional covariate
  ######################################
  source('utilities_preprocess_function.R')
  source('utilities_parse.predict.pfr.R')
  
  X.training.na <- X.training             # save sparse/noisy X mat for training set
  X.test.na <- X.test                     # save sparse/noisy X mat for testing set
  pre <- preprocess.pfr(covariates = t(t(U.training)), 
                        funcs = list(X.training.na), 
                        pve = pve,kz = NULL,smooth.option="fpca.sc", nbasis=10, kb=30)
  X.training <- pre$X[,-c(1,2)]
  
  new.data <- list(subj = NULL, covariates=t(t(U.test)), funcs = X.test.na)
  par <- parse.predict.pfr(pfr.obj = pre, new.data = new.data)
  pre.test <- preprocess.pfr(subj=par$subj.new,
                             covariates=par$covariates.new, funcs=par$funcs.old, 
                             kz=par$kz.old, kb=par$kb.old,nbasis=par$nbasis.old,
                             funcs.new=par$funcs.new,smooth.option=par$smooth.option.old)   
  X.test <- pre.test$X[,-c(1,2)]
  
  ########################################################
  # Joint estimation of conditional distribution function
  ########################################################
  source('utilities_logit_function.R')
  sort.y <- sort(Y.training)                   # Sort Y          
  fixed.y <- seq(sort.y[5], sort.y[length(sort.y)-5],length.out=100)  # Grid of y
  ind.var.training <- sapply(fixed.y, function(a) ifelse(Y.training <= a, 1, 0))

  # PFFR(B) (incoporate both scalar and functional covariates)
  pffr.dat <- list()
  pffr.dat$Y <- ind.var.training    # Artificial binary response
  pffr.dat$U <- U.training          # Scalar covariate
  pffr.dat$X <- X.training          # Functional covariate
  fit.pffr <- pffr(Y ~ ff(X, xind = ti)+U, yind=fixed.y, data=pffr.dat, family = binomial())
  predF <- logit(predict(fit.pffr, newdata=list(U=U.test,X=X.test)))
  predF.mono <- t(apply(predF, 1, function(a) isoreg(fixed.y, a)$yf)) #Monotonic
  
  ################################
  # Predict conditional quantile 
  ################################
  predQ <- matrix(NA,length(Y.test),length(tau))
  for (i in seq_len(length(Y.test)))
  {
    predQ[i,] <- sapply(tau,function(a) ifelse(tail(predF.mono[i,],1) <= a, 
                                               tail(fixed.y,1),
                                               fixed.y[head(which(predF.mono[i,] > a),1)]))
  }
  
  ################################
  # Output
  ################################
  return(list(predF.mono=predF.mono, predQ=predQ, fixed.y=fixed.y, fit.pffr=fit.pffr))
  
}
