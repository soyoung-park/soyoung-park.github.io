Functional Data Analysis for Quantile Regression Modeling

This folder contains the following files

1. 'QuantileReg_FDA.R' is the implementation of joint quantile regression for functional data;

2. 'Demo.R' demonstrates the usage of the proposed method through a numerical example with simulated data;

3. 'Demo.html' is the html output of 'Demo.R';

4. 'utilities_logit_function.R' contains the utility logit function for estimation;

5. 'utilities_preprocess_function.R' is the utility function for pre-smoothing before estimation, originally from refund package;

6. 'utilities_parse.predict.pfr.R' is the utility function for pre-smoothing before estimation, originally from refund package.




Cai Li
3/20/2016