#logit function
logit <- function(x) {
  #numerical perks to avoid crash
  x[x > 20] = 20
  return(exp(x)/(exp(x) + 1))
}